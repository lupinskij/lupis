<?php //pagination ?>
<div class="pagination">
	<?php jeffreyWP_pagination(); ?>
</div>
<?php //pagination ?>